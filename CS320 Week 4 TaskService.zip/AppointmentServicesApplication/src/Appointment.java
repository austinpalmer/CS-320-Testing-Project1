import java.util.Date;

public class Appointment {
	// Initialize Appointment variables
	private String id;
	private Date date;
	private String description;
	
	// Constructor
	public Appointment(String id, Date date, String description) {
		if (id == null || id.length()>10) {
			throw new IllegalArgumentException("Invalid ID");
		}
		if (date == null || date.before(new Date())) {
			throw new IllegalArgumentException("Invalid date");
		}
		if (description == null || description.length()>50) {
			throw new IllegalArgumentException("Invalid description");
		}
		this.id = id;
		this.date = date;
		this.description = description;
	}
	
	// Setters
	public void setID(String id) {
		this.id = id;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public void setDesc(String description) {
		this.description = description;
	}
	// Getters
	public String getID() {
		return id;
	}
	public Date getDate() {
		return date;
	}
	public String getDesc() {
		return description;
	}
}
