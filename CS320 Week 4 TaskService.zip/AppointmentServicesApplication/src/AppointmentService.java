import java.util.ArrayList;
import java.util.Date;

public class AppointmentService {
	public ArrayList<Appointment> appointments;
		
	// Default Constructor
	public AppointmentService() {
		appointments = new ArrayList<Appointment>();
	}
	// Add appointment
	public boolean add(Appointment appointment) {
		boolean inList = false;
		/* 
		 * Loop through the list of appointments to
		 * check that the appointment not there already
		*/
		for (Appointment a : appointments) {
			// If appointment is in list, set true
			if (a.equals(appointment)) {
				inList = true;
			}
		}
		// Add the appointment if not in list
		if (!inList){
			appointments.add(appointment);
			return true;
		}
		// Otherwise print status and return false
		else {
			System.out.println("Appointment already exists.");
			return false;
		}
	}
	// Delete an appointment if on list
	public boolean delete(String id) {
		// Loop through appointment list
		for (Appointment a : appointments) {
			// If appointment is in list, remove it
			if (a.getID().equals(id)) {
				appointments.remove(a);
				return true;
			}
		}
		// If task is not in list, return false
		System.out.println("Appointment does not exist.");
		return false;
	}
}
