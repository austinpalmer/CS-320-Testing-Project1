import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class AppointmentTest {
	Date d = new Date (2023, 02, 15);
	Date newD = new Date();
	/*
	 * Test to ensure Appointment construction
	 */
	@Test
	void testAppointment() {
		Appointment appointment = new Appointment("100", d, "Doctor's Appointment");
		assertTrue(appointment.getID().equals("100"));
		assertTrue(appointment.getDate().equals(d));
		assertTrue(appointment.getDesc().equals("Doctor's Appointment"));
	}
	/*
	 * Test to ensure id is not too long
	*/
	@Test
	void testIDLength() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("A12345678901", d, "Doctor's Appointment");
		}); }
	/*
	 * Test to ensure id is not null
	 */
	@Test
	void testIDNotNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment(null, d, "Doctor's Appointment");
		}); }
	/*
	 * Test that appointment is not in past
	 */
	@Test
	void testDate() {
		if (d.before(newD) == true) {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Appointment("100", d, "Doctor's Appointment");
			}); }
	}
	/*
	 * Test that appointment is not null
	 */
	void testDateNotNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("100", null, "Doctor's Appointment");
		}); }
	/*
	 * Test that description is not too long
	 */
	@Test
	void testDescLength() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("100", d, "ABCEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEF");
		}); }
	/*
	 * Test to ensure description is not null
	 */
	@Test
	void testDescNotNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("100", d, null);
		}); }


}

