import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

class AppointmentServiceTest {
	Date d = new Date(2023, 02, 15);
	Date e = new Date(2023, 02, 25);
	/*
	 * Test that the addition of appointments 
	 * method returns true when the appointment doesn't
	 * already exist
	 */
	@Test
	void testMethodAddApptTrue() {
		// Create new instance of AppointmentService
		AppointmentService apptService = new AppointmentService();
		// Create 2 appointments to be tested in the appointment list
		Appointment appt1 = new Appointment("100", d, "Doctor's Appointment");
		Appointment appt2 = new Appointment("200", e, "Office Meeting");
		// Assert the method to be true, add the tasks
		assertEquals(true, apptService.add(appt1));
		assertEquals(true, apptService.add(appt2));
	}
	/*
	 * Test that the addition of appointment
	 * method returns false when the appointment
	 * already exist
	 */
	@Test
	void testMethodAddApptFalse() {
		// Create new instance of AppointmentService
		AppointmentService apptService = new AppointmentService();
		// Create 2 appointments to be tested in the appointment list
		Appointment appt1 = new Appointment("100", d, "Doctor's Appointment");
		Appointment appt2 = new Appointment("200", e, "Office Meeting");
		// Add appts to list
		assertEquals(true, apptService.add(appt1));
		assertEquals(true, apptService.add(appt2));
		// Add appointments to list again, should return false
		assertEquals(false, apptService.add(appt1));
		assertEquals(false, apptService.add(appt2));
	}
	/*
	 * Test that the deletion of appointments
	 * method returns true when appointment
	 * exists
	 */
	@Test
	void testMethodDeleteTrue() {
		// Create new instance of AppointmentService
		AppointmentService apptService = new AppointmentService();
		// Create 2 appointments to be tested in the appointment list
		Appointment appt1 = new Appointment("100", d, "Doctor's Appointment");
		Appointment appt2 = new Appointment("200", e, "Office Meeting");
		// Add appts to list
		assertEquals(true, apptService.add(appt1));
		assertEquals(true, apptService.add(appt2));
		// Delete appts 100 and 200
		assertEquals(true, apptService.delete("100"));
		assertEquals(true, apptService.delete("200"));
	}
	/*
	 * Test that the deletion of appointments
	 * method returns false when appointment
	 * doesn't exist
	 */
	@Test
	void testMethodDeleteFalse() {
		// Create new instance of AppointmentService
		AppointmentService apptService = new AppointmentService();
		// Create 2 appointments to be tested in the appointment list
		Appointment appt1 = new Appointment("100", d, "Doctor's Appointment");
		Appointment appt2 = new Appointment("200", e, "Office Meeting");
		// Add appts to list
		assertEquals(true, apptService.add(appt1));
		assertEquals(true, apptService.add(appt2));
		// Delete appts 100 and 300
		assertEquals(true, apptService.delete("100"));
		assertEquals(false, apptService.delete("300"));
	}
}

