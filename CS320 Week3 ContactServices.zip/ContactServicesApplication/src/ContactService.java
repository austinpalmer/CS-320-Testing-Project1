import java.util.ArrayList;

public class ContactService {
	// Create contact list
	private ArrayList<Contact> contacts;
	
	// Default Constructor
	public ContactService() {
		contacts = new ArrayList<Contact>();
	}
	// Add Contact if not in list
	public boolean add(Contact contact) {
		boolean inList = false;
		/* 
		 * Loop through the list of contacts to
		 * check that the contact not there already
		 */
		for (Contact con : contacts) {
			// If contact is in list, set true
			if (con.equals(contact)) {
				inList = true;
			}
		}
		// Add the contact if not in list
		if (!inList){
			contacts.add(contact);
			return true;
		}
		// Otherwise print status and return false
		else {
			System.out.println("Contact already exists.");
			return false;
		}
	}
	
	// Remove a contact if on list
	public boolean remove(String ID) {
		// Loop through contact list
		for (Contact con : contacts) {
			// If contact is in list, remove it
			if (con.getID().equals(ID)) {
				contacts.remove(con);
				return true;
			}
		}
		// If contact is not in list, return false
		System.out.println("Contact does not exist.");
		return false;
	}
	
	/*
	 * Update contact information based on input.
	 * If input entered is an empty string, no changes
	 * to the contact will be made
	 */
	public boolean update(String ID, String firstName, String lastName, String address) {
		// Loop through contact list to find specified ID
		for (Contact con : contacts) 
			// If contact is found
			if (con.getID().equals(ID)) {
				if (!firstName.equals("")) {
					// Update firstName
					con.setFirstName(firstName);
				}
				if (!lastName.equals("")) {
					// Update lastName
					con.setLastName(lastName);
				}
				if (!address.equals("")) {
					// Update address
					con.setAddress(address);
				}
				return true;
			}
		System.out.println("Contact does not exist, please try again.");
		return false;
	}
}
