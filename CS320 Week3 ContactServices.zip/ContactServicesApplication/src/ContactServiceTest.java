import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
// JUnit Test class for ContactService
class ContactServiceTest {
	
	/*
	 * Test that the addition of contacts 
	 * method returns true when the contact doesn't
	 * already exist
	 */
	@Test
	void testMethodAddTrue() {
		// Create new instance of ContactService
		ContactService contactService = new ContactService();
		// Create 2 contacts to be tested in the contacts list
		Contact contact1 = new Contact("A1", "Sam", "Smith", "8001234567", "100 Smith Rd");
		Contact contact2 = new Contact("A2", "John", "Legend", "8002569588", "20 Park Dr");
		// Assert the method to be true, add the contacts
		assertEquals(true, contactService.add(contact1));
		assertEquals(true, contactService.add(contact2));
	}
	/*
	 * Test that the addition of contacts
	 * method returns false when the contact
	 * already exist
	 */
	@Test
	void testMethodAddFalse() {
		// Create new instance of ContactService
		ContactService contactService = new ContactService();
		// Create 2 contacts to be tested in the contacts list
		Contact contact1 = new Contact("A1", "Sam", "Smith", "8001234567", "100 Smith Rd");
		Contact contact2 = new Contact("A2", "John", "Legend", "8002569588", "20 Park Dr");
		// Add contacts to list
		assertEquals(true, contactService.add(contact1));
		assertEquals(true, contactService.add(contact2));
		// Add contacts to list again, should return false
		assertEquals(false, contactService.add(contact1));
		assertEquals(false, contactService.add(contact2));
	}
	/*
	 * Test that the deletion of contacts
	 * method returns true when the contact
	 * does exist
	 */
	@Test
	void testMethodDeleteTrue() {
		// Create new instance of ContactService
		ContactService contactService = new ContactService();
		// Create 2 contacts to be tested in the contacts list
		Contact contact1 = new Contact("A1", "Sam", "Smith", "8001234567", "100 Smith Rd");
		Contact contact2 = new Contact("A2", "John", "Legend", "8002569588", "20 Park Dr");
		// Add contacts to list
		assertEquals(true, contactService.add(contact1));
		assertEquals(true, contactService.add(contact2));
		// Remove contacts with ID "A1" and "A2" from list
		assertEquals(true, contactService.remove("A1"));
		assertEquals(true, contactService.remove("A2"));
	}
	/*
	 * Test that the deletion of contacts
	 * method returns false when contact
	 * doesn't exist
	 */
	@Test
	void testMethodDeleteFalse() {
		// Create new instance of ContactService
		ContactService contactService = new ContactService();
		// Create 2 contacts to be tested in the contacts list
		Contact contact1 = new Contact("A1", "Sam", "Smith", "8001234567", "100 Smith Rd");
		Contact contact2 = new Contact("A2", "John", "Legend", "8002569588", "20 Park Dr");
		// Add contacts to list
		assertEquals(true, contactService.add(contact1));
		assertEquals(true, contactService.add(contact2));
		// Remove "A1" and "A3" from the list, "A1" should return true "A3" should return false
		assertEquals(true, contactService.remove("A1"));
		assertEquals(false, contactService.remove("A3"));
	}
	/*
	 * Test that updating contacts updates information 
	 * and ignores on any String arguments
	 */
	@Test
	void testMethodUpdateTrue() {
		// Create new instance of ContactService
		ContactService contactService = new ContactService();
		// Create 2 contacts to be tested in the contacts list
		Contact contact1 = new Contact("A1", "Sam", "Smith", "8001234567", "100 Smith Rd");
		Contact contact2 = new Contact("A2", "John", "Legend", "8002569588", "20 Park Dr");
		// Add contacts to list
		assertEquals(true, contactService.add(contact1));
		assertEquals(true, contactService.add(contact2));
		
		// Test by updating all info on "A1" and skip update on first/last name of "A2"
		assertEquals(true, contactService.update("A1", "John", "Davison", "20 Smith Rd"));
		assertEquals(true, contactService.update("A2", "", "", "100 Park Dr"));
	}
	/*
	 * Test that updating contacts 
	 * that do not exist returns false
	 */
	@Test
	void testMethodUpdateFalse() {
		// Create new instance of ContactService
		ContactService contactService = new ContactService();
		// Create 2 contacts to be tested in the contacts list
		Contact contact1 = new Contact("A1", "Sam", "Smith", "8001234567", "100 Smith Rd");
		Contact contact2 = new Contact("A2", "John", "Legend", "8002569588", "20 Park Dr");
		// Add contacts to list
		assertEquals(true, contactService.add(contact1));
		assertEquals(true, contactService.add(contact2));
		
		assertEquals(false, contactService.update("A3", "Taylor", "Swift", "500 Swift Rd"));
		assertEquals(true, contactService.update("A1", "John", "Davison", "20 Smith Rd"));
	}
}
