
public class Contact {
	// Initialize Contact variables
	private String ID;
	private String firstName;
	private String lastName;
	private String phoneNum;
	private String address;
	
	// Default Constructor
	public Contact() {
		this.ID = "";
		this.firstName = "";
		this.lastName = "";
		this.phoneNum = "";
		this.address = "";
	}
	// Constructor with Contact Variables
	public Contact(String ID, String firstName, String lastName, String phoneNum, String address) {
		if (ID == null || ID.length()>10) {
			throw new IllegalArgumentException("Invalid ID");
		}
		if (firstName == null || firstName.length()>10) {
			throw new IllegalArgumentException("Invalid first name");
		}
		if (lastName == null || lastName.length()>10) {
			throw new IllegalArgumentException("Invalid last name");
		}
		if (phoneNum == null || phoneNum.length()!=10) {
			throw new IllegalArgumentException("Invalid phone number");
		}
		if (address == null || address.length()>30) {
			throw new IllegalArgumentException("Invalid address");
		}
		this.ID = ID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
	}
	// Setters
	public void setID(String ID) {
		this.ID = ID;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public void setPhoneNumber(String phoneNum) {
		this.phoneNum = phoneNum;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	// Getters
	public String getID() {
		return ID;
	}
	public String getFirstName() {
		return firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public String getPhoneNumber() {
		return phoneNum;
	}
	public String getAddress() {
		return address;
	}
}
