import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ContactTest {
	/*
	 * Test to ensure the constructor correctly associates
	 * information based on ID, firstName, lastName, and address
	 */
	@Test
	void testContact() {
		Contact contact = new Contact("A1", "Sam", "Smith", "8001234567", "100 Smith Rd");
		assertTrue(contact.getID().equals("A1"));
		assertTrue(contact.getFirstName().equals("Sam"));
		assertTrue(contact.getLastName().equals("Smith"));
		assertTrue(contact.getAddress().equals("100 Smith Rd"));
	}
	/*
	 * Test to ensure ID is not too long
	 */
	@Test
	void testIDLength() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("A12345678901", "Sam", "Smith", "8001234567", "100 Smith Rd");
		}); }
	/*
	 * Test to ensure ID is not null
	 */
	@Test
	void testIDNotNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, "Sam", "Smith", "8001234567", "100 Smith Rd");
		}); }
	/*
	 * Test to ensure firstName is not too long
	 */
	@Test
	void testfistNameLength() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("A1", "Samantha Lynn", "Smith", "8001234567", "100 Smith Rd");
		}); }
	/*
	 * Test to ensure firstName is not null
	 */
	@Test
	void testFirstNameNotNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("A1", null, "Smith", "8001234567", "100 Smith Rd");
		}); }
	/*
	 * Test to ensure lastName is not too long
	 */
	@Test
	void testLastNameLength() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("A1", "Sam", "Smithsoniansss", "8001234567", "100 Smith Rd");
		}); }
	/*
	 * Test to ensure lastName is not null
	 */
	@Test
	void testLastNameNotNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("A1", "Sam", null, "8001234567", "100 Smith Rd");
		}); }
	/*
	 * Test to ensure phone is not more than 10 characters
	 */
	@Test
	void testPhoneLength() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("A1", "Sam", "Smith", "80012345611117", "100 Smith Rd");
		}); }
	/*
	 * Test to ensure lastName is not null
	 */
	@Test
	void testPhoneNotNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("A1", "Sam", "Smith", null, "100 Smith Rd");
		}); }
	/*
	 * Test to ensure address is not too long
	 */
	@Test
	void testAddressLength() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("A1", "Sam", "Smithsoniansss", "8001234567", "100 Smithsonian New York City New York 72754 United States of America");
		}); }
	/*
	 * Test to ensure address is not null
	 */
	@Test
	void testAddressNotNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("A1", "Sam", null, "8001234567", "100 Smith Rd");
		}); }
}
